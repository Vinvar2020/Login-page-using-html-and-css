<?php
if(isset($_POST['uname']) && isset($_POST['Password']))
{
    function validate($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    $uname = validate($_POST['uname']);
    $pass = validate($_POST['Password']);

    if(empty($uname))
    {
        header("Location: Login.php?error=Username is required");
        exit();
    }
    else if(empty($pass))
    {
        header("Location: Login.php?error=Password is required");
        exit();
    }
    else
    {
        echo "Valid input";
    }
}
else
{
    header("Location: Login.php");
    exit();
}
